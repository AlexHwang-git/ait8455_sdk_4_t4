/*-------------------------------------------------------------------*/
/*  Copyright(C) 2011-2012 by OMRON Corporation                      */
/*  All Rights Reserved.                                             */
/*                                                                   */
/*   This source code is the Confidential and Proprietary Property   */
/*   of OMRON Corporation.  Any unauthorized use, reproduction or    */
/*   transfer of this software is strictly prohibited.               */
/*                                                                   */
/*-------------------------------------------------------------------*/
#include    "OkaoTime.h"

/* Initialization of time */
UINT32  OkaoExtraInitTime(void)
{
    return ( UINT32 )( 0 );
}

/* Get of Time (ms) from initialization */
UINT32  OkaoExtraGetTime(UINT32 glOkaoDtStartTime)
{
    return ( UINT32 )( 0 );
}
