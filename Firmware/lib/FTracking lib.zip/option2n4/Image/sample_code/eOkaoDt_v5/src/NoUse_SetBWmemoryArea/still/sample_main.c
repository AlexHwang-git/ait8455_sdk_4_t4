/*-------------------------------------------------------------------*/
/*  Copyright(C) 2012 by OMRON Corporation                           */
/*  All Rights Reserved.                                             */
/*                                                                   */
/*   This source code is the Confidential and Proprietary Property   */
/*   of OMRON Corporation.  Any unauthorized use, reproduction or    */
/*   transfer of this software is strictly prohibited.               */
/*                                                                   */
/*-------------------------------------------------------------------*/

/*
   Sample Code of Face Detection V5 without setting Backup and Working memory. (Still Image Sample)
*/

#include <stdio.h>
#include <string.h>
#include "OkaoAPI.h"
#include "CommonDef.h"
#include "OkaoDtAPI.h"
#include "GrayImage.h"

#define LOGBUFFERSIZE	1024

/* Print Log Message */
static void PrintLog(char *pStr)
{
    puts(pStr);
}


/* Set Face Detection parameters */
static BOOL SetDtParameters(HDETECTION hDT, char *pStr)
{
    INT32 nRet = OKAO_ERR_VARIOUS;
    RECT rcStillArea;
    RECT rcMotionArea;
    UINT32 anAngle[POSE_TYPE_COUNT];
    INT32 nMotionAngleExtension;

    /* Sets the Face Detection Mode */
    nRet = OKAO_SetDtMode(hDT, DT_MODE_DEFAULT);
    if (nRet != OKAO_NORMAL) {
        sprintf( &pStr[strlen(pStr)], "OKAO_SetDtMode() Error : %d\n", nRet );
        return FALSE;
    }

    /* Sets the Minimum and Maximum face sizes to be detected */
    nRet = OKAO_SetDtFaceSizeRange(hDT, 40, 8192);
    if (nRet != OKAO_NORMAL) {
        sprintf( &pStr[strlen(pStr)], "OKAO_SetDtFaceSizeRange() Error : %d\n", nRet );
        return FALSE;
    }

    /* Sets the Angle settings for face detection */
    anAngle[POSE_FRONT] = ANGLE_0;
    anAngle[POSE_HALF_PROFILE] = ANGLE_NONE;
    anAngle[POSE_PROFILE] = ANGLE_NONE;
    nMotionAngleExtension = ANGLE_ROTATION_EXT1 | ANGLE_POSE_EXT1 | DETECT_HEAD_USE;
    nRet = OKAO_SetDtAngle(hDT, anAngle, nMotionAngleExtension);
    if (nRet != OKAO_NORMAL) {
        sprintf( &pStr[strlen(pStr)], "OKAO_SetDtAngle() Error : %d\n", nRet );
        return FALSE;
    }

    /* Sets the Direction Mask for Motion mode */
    nRet = OKAO_SetDtDirectionMask(hDT, TRUE);
    if (nRet != OKAO_NORMAL) {
        sprintf( &pStr[strlen(pStr)], "OKAO_SetDtDirectionMask() Error : %d\n", nRet );
        return FALSE;
    }

    /* Sets the timeout time for OKAO_Detection() */
    nRet = OKAO_SetDtTimeout(hDT, 0, 0);
    if (nRet != OKAO_NORMAL) {
        sprintf( &pStr[strlen(pStr)], "OKAO_SetDtTimeout() Error : %d\n", nRet );
        return FALSE;
    }

    /* Sets the Face Detction Rectangular Mask */
    rcStillArea.left = -1;
    rcStillArea.top = -1;
    rcStillArea.right = -1;
    rcStillArea.bottom = -1;
    rcMotionArea.left = -1;
    rcMotionArea.top = -1;
    rcMotionArea.right = -1;
    rcMotionArea.bottom = -1;
    nRet = OKAO_SetDtRectangleMask(hDT, rcStillArea, rcMotionArea);
    if (nRet != OKAO_NORMAL) {
        sprintf( &pStr[strlen(pStr)], "OKAO_SetDtRectangleMask() Error : %d\n", nRet );
        return FALSE;
    }

    /* Sets the Face Detection Threshold */
    nRet = OKAO_SetDtThreshold(hDT, 500, 500);
    if (nRet != OKAO_NORMAL) {
        sprintf( &pStr[strlen(pStr)], "OKAO_SetDtThreshold() Error : %d\n", nRet );
        return FALSE;
    }

    /* Sets the search density coefficient for face detection */
    nRet = OKAO_SetDtStep(hDT, 33, 33);
    if (nRet != OKAO_NORMAL) {
        sprintf( &pStr[strlen(pStr)], "OKAO_SetDtStep() Error : %d\n", nRet );
        return FALSE;
    }

    return TRUE;
}


int main(void)
{
    INT32 nRet = OKAO_ERR_VARIOUS;  /* Return code */
    INT32 nFaceCount;               /* The number of detected face */
    INT32 nIndex;                   /* Index of face detection */
    FACEINFO info;                  /* Detection Result */

    RAWIMAGE *pGray = (RAWIMAGE *)&GrayImage[0];    /* Raw image data (gray) */
    const INT32 nWidth = 320;       /* Image width */
    const INT32 nHeight = 240;      /* Image height */

    HDETECTION hDT = NULL;          /* Face Detection Handle */
    HDTRESULT hDtResult = NULL;     /* Face Detection Result Handle */
    char *pStr;                     /* String Buffer for logging output */

    /*****************************/
    /* Logging Buffer allocation */
    /*****************************/
    pStr = (char *)malloc(LOGBUFFERSIZE);
    if ( pStr == NULL ) {
	    return (-1);
    }
    memset(pStr, 0, LOGBUFFERSIZE);

    do {
        /********************************/
        /* Face Detection Settings      */
        /********************************/
        /* Creates Face Detection handle */
        hDT = OKAO_CreateDetection();
        if ( hDT == NULL ) {
            sprintf( &pStr[strlen(pStr)], "OKAO_CreateDetection() Error\n" );
            break;
        }
        /* Creates Face Detection result handle */
        hDtResult = OKAO_CreateDtResult(35, 0);
        if ( hDtResult == NULL ) {
            sprintf( &pStr[strlen(pStr)], "OKAO_CreateDtResult() Error\n" );
            break;
        }
        /* Sets Face Detection parameters */
        if ( SetDtParameters(hDT, pStr) != TRUE ) {
            break;
        }

        /******************/
        /* Face detection */
        /******************/
        /* Executes Face Detection */
        nRet = OKAO_Detection(hDT, pGray, nWidth, nHeight, ACCURACY_NORMAL, hDtResult);
        if ( nRet != OKAO_NORMAL ) {
            sprintf( &pStr[strlen(pStr)], "OKAO_Detection() Error : %d\n", nRet );
            break;
        }
        /* Gets the number of detected face */
        nRet = OKAO_GetDtFaceCount(hDtResult, &nFaceCount);
        if ( nRet != OKAO_NORMAL ) {
            sprintf( &pStr[strlen(pStr)], "OKAO_GetDtFaceCount() Error : %d\n", nRet );
            break;
        }
        sprintf( &pStr[strlen(pStr)], "\nOKAO_GetDtFaceCount() OK : nFaceCount = %d\n", nFaceCount );
        for ( nIndex = 0; nIndex < nFaceCount; nIndex++ ) {   /*** Face Loop ***/
            /* Gets the detection result for each face */
            nRet = OKAO_GetDtFaceInfo(hDtResult, nIndex, &info);
            if ( nRet != OKAO_NORMAL ) {
                sprintf( &pStr[strlen(pStr)], "OKAO_GetDtFaceInfo(%d) Error : %d\n", nIndex, nRet );
                break;
            }
            sprintf( &pStr[strlen(pStr)], "   <NO.%d>  (Confidence=%d, [%d,%d][%d,%d][%d,%d][%d,%d], ID=%d)\n",
                                nIndex, info.nConfidence,
                                info.ptLeftTop.x, info.ptLeftTop.y,
                                info.ptRightTop.x, info.ptRightTop.y,
                                info.ptLeftBottom.x, info.ptLeftBottom.y,
                                info.ptRightBottom.x, info.ptRightBottom.y,
                                info.nID);
        }
    } while(0);
    /******************/
    /* logging output */
    /******************/
    PrintLog(pStr);

    /********************************/
    /* Handle Deletion              */
    /********************************/
    /* Deletes Face Detection handle */
    if ( hDT != NULL ) {
        OKAO_DeleteDetection(hDT);
    }
    /* Deletes Face Detection result handle */
    if ( hDtResult != NULL ) {
        OKAO_DeleteDtResult(hDtResult);
    }

    /* Free Logging Buffer */
    if ( pStr != NULL ) {
        free(pStr);
    }
    return (0);
}
