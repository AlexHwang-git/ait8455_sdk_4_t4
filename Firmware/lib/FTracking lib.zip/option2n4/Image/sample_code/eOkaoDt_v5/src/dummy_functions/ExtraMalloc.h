/*-------------------------------------------------------------------*/
/*  Copyright(C) 2003-2012 by OMRON Corporation                      */
/*  All Rights Reserved.                                             */
/*                                                                   */
/*   This source code is the Confidential and Proprietary Property   */
/*   of OMRON Corporation.  Any unauthorized use, reproduction or    */
/*   transfer of this software is strictly prohibited.               */
/*                                                                   */
/*-------------------------------------------------------------------*/

#ifndef SDKEXTRA_H__
#define SDKEXTRA_H__

#define OKAO_API

#include "OkaoDef.h"

#ifdef  __cplusplus
extern "C" {
#endif

/*----- Memory control -----*/
OKAO_API void       *OkaoExtraMalloc( UINT32 mSize );   /* Setting of user definition memory area */

OKAO_API void       OkaoExtraFree( void *pPtr );        /* Release of user definition memory area */

#ifdef  __cplusplus
}
#endif

#endif  /* SDKEXTRA_H__ */
