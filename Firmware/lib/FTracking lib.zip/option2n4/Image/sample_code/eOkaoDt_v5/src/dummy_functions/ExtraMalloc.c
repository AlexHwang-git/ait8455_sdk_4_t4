/*-------------------------------------------------------------------*/
/*  Copyright(C) 2003-2012 by OMRON Corporation                      */
/*  All Rights Reserved.                                             */
/*                                                                   */
/*   This source code is the Confidential and Proprietary Property   */
/*   of OMRON Corporation.  Any unauthorized use, reproduction or    */
/*   transfer of this software is strictly prohibited.               */
/*                                                                   */
/*-------------------------------------------------------------------*/
#include    "ExtraMalloc.h"

/*****************************************************************************
Function              : Setting of user definition memory area
Return value          : error code
Function explanation  : The memory area is set
*****************************************************************************/
void  *OkaoExtraMalloc(
    UINT32 mSize)                      /* Memory Size*/
{
    /* dummy implementation */
    return 0;

    /* Please convert it for your environment as below. */
    /*    return malloc( mSize );                       */
    
}


/*****************************************************************************
Function              : Release of user definition memory area
Return value          : void
Function explanation  : The memory area is released
*****************************************************************************/
void OkaoExtraFree(
    void *pPtr)                      /* Release head address */
{
    /* dummy implementation */

    /* Please convert it for your environment as below */
    /*    free(pPtr);                                  */
    
}
