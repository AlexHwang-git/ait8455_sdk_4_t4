-----------------------------------------------------------------------
 OKAO Vision Sample Code (Face Detection V5)
-----------------------------------------------------------------------

(1) Sample Code Contents
 There are 2 different sample codes, i.e. Still Image Sample Code and Movie Image Sample Code, each available in 2 different situations,
 i.e. whether Setting the Backup Memory & Work Memory or Not Setting the Backup Memory & Work Memory, for a total of 4 sample codes.

 The Still Image Sample Code processes an image containing the faces of 3 subjects before logging the ouput result.
 The Movie Image Sample Code prepairs and processes in order 5 continuous frames containing the face of 1 subject before logging the output result.

 If setting the Backup Memory & Work Memory, the memory area used by the OKAO Vision Library to set values can be pre-allocated.
 If not setting the Backup Memory & Work Memory, the memory allocation and deallocation must be done every time.

 In this Sample code, the image data has been embedded in the header as a char array instead of the image file.
 This is done in order to avoid any file processing operations in embedded environments

(2) Directory Structure
      image/                    Original image of sample
                                RAW Data of the original image, not used in the sample code.
        movie/
          GrayImage01.bmp         Original image of sample for Movie (frame #1)
          GrayImage02.bmp         Original image of sample for Movie (frame #2)
          GrayImage03.bmp         Original image of sample for Movie (frame #3)
          GrayImage04.bmp         Original image of sample for Movie (frame #4)
          GrayImage05.bmp         Original image of sample for Movie (frame #5)
        still/
          GrayImage.bmp           Original image of sample for Still Image
      src/
        NoUse_SetBWmemoryArea/  Sample code when not setting the Backup Memory and Work Memory
          movie/                  Sample code for Movie Image
            sample_main.c           Sample source code
            GrayImage01.h           Sample Image RAW data (frame #1)
            GrayImage02.h           Sample Image RAW data (frame #2)
            GrayImage03.h           Sample Image RAW data (frame #3)
            GrayImage04.h           Sample Image RAW data (frame #4)
            GrayImage05.h           Sample Image RAW data (frame #5)
          still/                  Sample code for Still Image
            sample_main.c           Sample source code
            GrayImage.h             Sample Image RAW data

        Use_SetBWmemoryArea/    Sample code when setting the Backup Memory and Work memory
          movie/                  Sample code for Movie Image
            sample_main.c           Sample source code
            GrayImage01.h           Sample Image RAW data (frame #1)
            GrayImage02.h           Sample Image RAW data (frame #2)
            GrayImage03.h           Sample Image RAW data (frame #3)
            GrayImage04.h           Sample Image RAW data (frame #4)
            GrayImage05.h           Sample Image RAW data (frame #5)
          still/                  Sample code for Still Image
            sample_main.c           Sample source code
            GrayImage.h             Sample Image RAW data

        dummy_functions/        Dummy function sample code
          OkaoTime.c              Dummy function for Timeout
          ExtraMalloc.c           Dummy function for Backup Memory allocation
                                  These dummy functions need to be implemented depending on the used environment.
                                  Please refer to (3) Procedure for details.

(3) Procedure
   1. OkaoExtraMalloc()and OkaoExtraFree() implementation
    *In PC (Windows/Linux/Mac), Android or Symbian environment:
     - No implementation needed.
    *In other environments:
     - If setting the Backup Memory and the Work Memory, use the ExtraMalloc.c dummy function included.      
     - If not setting the Backup Memory and the Work Memory, modify the ExtraMalloc.c dummy function to 
       be compatible with the used environment before using it.
       Memory allocation is done with OkaoExtraMalloc() and deallocation with OkaoExtraFree().

   2. malloc() and free() Replacement
    - This sample code uses the common functions malloc() and free().
      Modify them to be compatible with the used environment if necessary.

   3. Compiling and Linking
    - Depending on the used environment, create a makefile and project files to compile and link
    - Setting of the header and library files of the Common Functions and Face Detection are required for compiling and linking.
    - The linking order for the library is Face Detection, Common Functions.
      The order might vary depending on the linker. Please refer to the instruction manual of the linker if a link error occurs.
    - The created dummy function ExtraMalloc.c needs to be compiled and linked if working in an environment other than
      PC (Windows/Linux/Mac), Android or Symbian.
    - The dummy function for the timeout feature (OkaoTime.c) needs to be compiled and linked if working in an environment other than Windows.
    - The Import Library needs to be linked if working in Windows (DLL) environment. 

Caution:
    - Please note that the buffer used for logging might not be sufficient when replacing images as the number of 
      detected faces will increase.
      The size of the buffer used for logging can be changed with #define LOGBUFFERSIZE.

[USAGE NOTES]
 - Please use this sample code and this document following the Non-Disclosure Agreement (NDA).
 - The copyrights of this sample code and this document belong to OMRON Corporation.
 - The execution behaviour of this sample code is not guaranteed.

----
OMRON Corporation
Application Oriented Components Department
Software Device Development Section
Copyright(C) 2012 OMRON Corporation, All Rights Reserved.