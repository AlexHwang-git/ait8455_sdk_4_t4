Confidential                                                                    2012.06.29
--------------------------------------------------------------------------------------------
[OKAO SDK Software]
(1) Folder Structure
	doc:          Documents. (OKAO SDK Software Manual is placed here.)
	include:      Include files.
	lib:          Import library files.
	sample_code:  Sample Code files.

[Usage Undertaking]
�EThe copyrights of these software and documents belong to OMRON Corporation.

----
OMRON Corporation
Application Oriented Components Department
Software Device Development Section
Copyright(C) 2012 OMRON Corporation, All Rights Reserved.
